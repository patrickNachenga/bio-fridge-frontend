import React, { useState, useEffect } from "react";
import Swal from "sweetalert2";
import showToast from "../../helpers/ToastHelper";
import ReactLoading from "react-loading";
import usePagination from "../../hooks/usePagination";
import ReactPaginate from "react-paginate";
import "animate.css";
import { deleteFridge, getFridges } from "./Queries";
import { FridgeContext } from "../../utils/context";
import FridgeModal from "./Modal";
import IconSvg from "./fridge_svg";
import { Row } from "reactstrap";
import { getPercentageColor } from "../../helpers/PercentageColorHelper";
import { useNavigate } from "react-router-dom";

export const FridgePage = () => {
  const navigate = useNavigate();
  const pageSizeData = [6, 10, 20, 50, 70, 100];
  const [fridges, setFridges] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedFridge, setSelectedFridge] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [debounceTimeout, setDebounceTimeout] = useState(null);
  const {
    currentPage,
    totalCount,
    pageSize,
    updatePage,
    updatePageSize,
    updatePagination,
    updateTotalCount,
  } = usePagination(10, 1, true);

  const handlePageClick = (event) => {
    updatePage(event.selected + 1);
  };

  const handleFetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const result = await getFridges({
        search: searchQuery,
        pagination: {
          page: currentPage,
          page_size: pageSize,
          paginated: true,
        },
      });
      if (result.status === 200 || result.status === 8000) {
        setFridges(result.data);
        if (result.pagination) {
          updatePagination(result.pagination);
          updateTotalCount(result.pagination.total || 0);
        } else {
          updatePagination({});
        }
      } else {
        setError(true);
        showToast("No Fridge Found", "warning", "Fetch Completed");
      }
    } catch (err) {
      setError(true);
      showToast("Unable to Fetch Fridges", "warning", "Failed");
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (fridge = null) => {
    if (!fridge) {
      Swal.fire("Error!", "Unable to Select this Fridge.", "error");
      return;
    }

    try {
      const confirmation = await Swal.fire({
        title: "Are you sure?",
        text: "Your About to Delete the data",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        cancelButtonColor: "#aaa",
        confirmButtonText: "Yes, delete it!",
      });

      if (confirmation.isConfirmed) {
        const result = await deleteFridge(fridge.uid);
        if (result.status === 200 || result.status === 8000) {
          Swal.fire(
            "Process Completed!",
            "The Fridge has been deleted.",
            "success"
          );
          handleFetchData();
        } else {
          console.error("Error deleting Fridge:", result);
          Swal.fire("Error Occurred!", `${result.message}`, "error");
        }
      }
    } catch (error) {
      console.error("Error deleting Fridge:", error);
      Swal.fire(
        "Unsuccessful",
        `Unable to Perform Delete. Please Try Again or Contact Support Team`,
        "error"
      );
    }

    setSelectedFridge(null); // Reset selected Fridge after deletion
  };
  // Fetch Fridges on initial load
  useEffect(() => {
    if (debounceTimeout) clearTimeout(debounceTimeout);

    // Set new debounce timeout
    const timeout = setTimeout(() => {
      handleFetchData();
    }, 1500); // 2.5 seconds

    setDebounceTimeout(timeout);

    return () => clearTimeout(timeout); // Cleanup on unmount
  }, [searchQuery, pageSize, currentPage]); // Fetch when search query changes

  return (
    <FridgeContext.Provider
      value={{
        handleFetchData,
        selectedFridge,
        setSelectedFridge,
      }}
    >
      <h4 className="py-3 mb-4">
        <span className="text-muted fw-light">Setting /</span> Fridges
      </h4>
      <div className="card">
        <div className="d-flex justify-content-between align-items-center card-header">
          <h5 className="mb-0">List Of All Fridges</h5>
          <FridgeModal
            title="View Fridges"
            onClose={() => setSelectedFridge(null)}
          />
        </div>

        <div className="card-body ">
          <div className="d-flex justify-content-between align-items-center mb-2 animate__animated animate__fadeInDown animate__faster">
            <div className="d-flex align-items-center col-md-8 col-sm-6">
              <label className="text-sm font-medium me-2 mb-0">
                Rows per page:
              </label>
              <select
                value={pageSize}
                onChange={(e) => {
                  updatePageSize(Number(e.target.value));
                  updatePage(1);
                  updatePagination({
                    page: 1,
                    page_size: Number(e.target.value),
                  });
                }}
                className="form-select"
                aria-label="Default select example"
                style={{ width: "80px" }}
              >
                {pageSizeData.map((size) => (
                  <option key={size} value={size}>
                    {size}
                  </option>
                ))}
              </select>
            </div>
            <div className=" col-md-4 col-sm-6">
              <form className="d-flex">
                <div className="input-group">
                  <span className="input-group-text">
                    <i className="tf-icons bx bx-search"></i>
                  </span>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      updatePage(1);
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault();
                        handleFetchData();
                      }
                    }}
                  />
                </div>
              </form>
            </div>
          </div>

          <div className="text-nowrap animate__animated animate__fadeInUp animate__faster">
            <ul className="nav nav-pills mb-3 mt-4" role="tablist">
              <li className="nav-item">
                <button
                  aria-label="Click me"
                  type="button"
                  className="nav-link active"
                  role="tab"
                  style={{ width: "150px", height: "30px" }}
                  data-bs-toggle="tab"
                  data-bs-target="#navs-pills-top-tiles"
                  aria-controls="navs-pills-top-tiles"
                  aria-selected="true"
                >
                  <i className="bx bx-grid-alt me-1"></i>&nbsp;Tiles View
                </button>
              </li>
              <li className="nav-item">
                <button
                  aria-label="Click me"
                  type="button"
                  className="nav-link"
                  role="tab"
                  style={{ width: "150px", height: "30px" }}
                  data-bs-toggle="tab"
                  data-bs-target="#navs-pills-top-table"
                  aria-controls="navs-pills-top-table"
                  aria-selected="false"
                >
                  <i className="bx bx-table me-1"></i>&nbsp;Table View
                </button>
              </li>
            </ul>
            <div className="tab-content">
              <div
                className="tab-pane fade show active"
                id="navs-pills-top-tiles"
                role="tabpanel"
              >
                {loading ? (
                  <div className="col-md-12 col-lg-12 col-sm-12 p-2">
                    <center>
                      <ReactLoading
                        type={"cylon"}
                        color={"#696cff"}
                        height={"30px"}
                        width={"50px"}
                      />
                    </center>
                    <center className="mt-1">
                      <h6 className="text-muted">Fetching Fridges</h6>
                    </center>
                  </div>
                ) : error || fridges.length === 0 ? (
                  <div className="alert alert-info" role="alert">
                    <div className="alert-body text-center">
                      <p className="mb-0">No Data Found</p>
                    </div>
                  </div>
                ) : (
                  <Row className="row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
                    {fridges.map((dataRows, index) => (
                      <IconSvg
                        key={dataRows.uid}
                        onClick={() =>
                          navigate(`/fridges/open/${dataRows.uid}`)
                        }
                        label={dataRows.name}
                        block={dataRows.block_number}
                        sample={dataRows.sample_number}
                        capacity={dataRows.capacity}
                        percent={
                          dataRows.capacity <= 0
                            ? 0
                            : (
                                (dataRows.sample_number / dataRows.capacity) *
                                100
                              ).toFixed(2)
                        }
                        color={getPercentageColor(
                          dataRows.capacity <= 0
                            ? 0
                            : (
                                (dataRows.sample_number / dataRows.capacity) *
                                100
                              ).toFixed(2)
                        )}
                      />
                    ))}
                  </Row>
                )}
              </div>
              <div
                className="tab-pane fade teble-responsive"
                id="navs-pills-top-table"
                role="tabpanel"
              >
                <table className="table table-hover table-align-middle mb-0 table-bordered">
                  <thead style={{ backgroundColor: "#f1f1f1" }}>
                    <tr>
                      <th style={{ width: "50px" }}>S/N</th>
                      <th>Fridge Name</th>
                      <th style={{ width: "120px" }}>Registered At</th>
                      <th style={{ width: "100px" }}>Serial Number</th>
                      <th style={{ width: "100px" }}>Min Temp (&#176;C)</th>
                      <th style={{ width: "100px" }}>Max Temp (&#176;C)</th>
                      <th style={{ width: "100px" }}>Blocks</th>
                      <th style={{ width: "110px" }}>Sample Available</th>
                      <th style={{ width: "100px" }}>Status</th>
                      <th style={{ width: "60px" }}></th>
                    </tr>
                  </thead>
                  <tbody className="table-border-bottom-0">
                    {loading ? (
                      <tr>
                        <td colSpan="100%">
                          <div className="col-md-12 col-lg-12 col-sm-12 p-2">
                            <center>
                              <ReactLoading
                                type={"cylon"}
                                color={"#696cff"}
                                height={"30px"}
                                width={"50px"}
                              />
                            </center>
                            <center className="mt-1">
                              <h6 className="text-muted">Fetching Fridges</h6>
                            </center>
                          </div>
                        </td>
                      </tr>
                    ) : error || fridges.length === 0 ? (
                      <tr>
                        <td colSpan="100%">
                          <div className="alert alert-info" role="alert">
                            <div className="alert-body text-center">
                              <p className="mb-0">No Data Found</p>
                            </div>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      fridges.map((dataRows, index) => (
                        <tr key={dataRows.uid}>
                          <td>{(currentPage - 1) * pageSize + index + 1}</td>
                          <td className="fw-medium">
                            {dataRows.name} <code>({dataRows.code})</code>
                          </td>
                          <td className="fw-medium text-center">
                            {new Date(dataRows.created_at).toLocaleDateString(
                              "en-US",
                              {
                                year: "numeric",
                                month: "2-digit",
                                day: "2-digit",
                              }
                            )}
                            <br />
                            <small>
                              {new Date(dataRows.created_at).toLocaleTimeString(
                                "en-US",
                                {
                                  hour: "2-digit",
                                  minute: "2-digit",
                                  hour12: true,
                                }
                              )}
                            </small>
                          </td>
                          <td className="fw-medium">
                            {dataRows.serial_number}
                          </td>
                          <td className="fw-medium text-center">
                            {dataRows.minimum_temperature}
                          </td>
                          <td className="fw-medium text-center">
                            {dataRows.maximum_temperature}
                          </td>
                          <td className="fw-medium text-center">
                            {dataRows.block_number}
                          </td>
                          <td className="fw-medium text-center">
                            <div className="d-flex flex-column">
                              <span className="text-center mb-1">
                                {dataRows.sample_number} / {dataRows.capacity}
                              </span>
                              <div className="progress">
                                <div
                                  className="progress-bar"
                                  role="progressbar"
                                  style={{
                                    width: `${
                                      dataRows.capacity <= 0
                                        ? 0
                                        : (
                                            (dataRows.sample_number /
                                              dataRows.capacity) *
                                            100
                                          ).toFixed(2)
                                    }%`,
                                    backgroundColor: getPercentageColor(
                                      (
                                        (dataRows.sample_number /
                                          dataRows.capacity) *
                                        100
                                      ).toFixed(2)
                                    ),
                                  }}
                                  aria-valuenow={
                                    dataRows.capacity <= 0
                                      ? 0
                                      : (
                                          (dataRows.sample_number /
                                            dataRows.capacity) *
                                          100
                                        ).toFixed(2)
                                  }
                                  aria-valuemin="0"
                                  aria-valuemax="100"
                                >
                                  {dataRows.capacity <= 0
                                    ? 0
                                    : (
                                        (dataRows.sample_number /
                                          dataRows.capacity) *
                                        100
                                      ).toFixed(1)}
                                  %
                                </div>
                              </div>
                            </div>
                          </td>
                          <td>
                            <span
                              className={
                                dataRows.is_active
                                  ? "badge bg-label-success me-1"
                                  : "badge bg-label-danger me-1"
                              }
                            >
                              {dataRows.is_active ? "Available" : "Full"}
                            </span>
                          </td>
                          <td className="text-center">
                            <button
                              aria-label="Click me"
                              type="button"
                              className="btn p-0 dropdown-toggle hide-arrow me-4 pointer"
                              onClick={() =>
                                navigate(`/fridges/open/${dataRows.uid}`)
                              }
                            >
                              view &nbsp;
                              <i className="bx bx-right-arrow-alt me-1"></i>
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="d-flex justify-content-between align-items-center mt-3">
              {/* Your content here */}
              <div></div>
              <ReactPaginate
                previousLabel={"Previous"}
                nextLabel={"Next"}
                breakLabel={"..."}
                pageCount={Math.ceil((totalCount || 0) / (pageSize || 1))}
                marginPagesDisplayed={2}
                pageRangeDisplayed={5}
                onPageChange={handlePageClick}
                containerClassName={"pagination justify-content-center"}
                pageClassName={"page-item"}
                pageLinkClassName={"page-link"}
                previousClassName={"page-item"}
                previousLinkClassName={"page-link"}
                nextClassName={"page-item"}
                nextLinkClassName={"page-link"}
                breakClassName={"page-item"}
                breakLinkClassName={"page-link"}
                activeClassName={"active"}
              />
            </div>
          </div>
        </div>
      </div>
    </FridgeContext.Provider>
  );
};
