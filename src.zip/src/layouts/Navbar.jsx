import { useDispatch, useSelector } from 'react-redux';
import getGreetingMessage from '../utils/greetingHandler';
import { logout } from '../redux/actions/authentication/logoutAction';
import { Navigate, useNavigate } from 'react-router-dom';
const Navbar = () => {
  const user = useSelector((state) => state.userReducer?.data);
  console.log('--------------user------------->', user)

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logout());
    navigate('/auth/login');
  };


  return (
    <nav
      className="layout-navbar navbar-detached navbar navbar-expand-xl align-items-center bg-navbar-theme container-fluid"
      id="layout-navbar">
      <div className="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
        <a aria-label='toggle for sidebar' className="nav-item nav-link px-0 me-xl-4" href="#">
          <i className="bx bx-menu bx-sm"></i>
        </a>
      </div>

      <div className="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
        {getGreetingMessage(user ? user.first_name : '')}
        <ul className="navbar-nav flex-row align-items-center ms-auto">
          <li className="nav-item navbar-dropdown dropdown-user dropdown">
            <a aria-label='dropdown profile avatar' className="nav-link dropdown-toggle hide-arrow" href="#" data-bs-toggle="dropdown">
              <div className="avatar avatar-online">
                <img
                  src={
                    user && user.photo !== ""
                      ? user.photo
                      : "/assets/img/avatars/1.png"
                  }
                  style={{ width: '40px', height: '40px' }}
                  className="w-px-40 rounded-circle"
                  alt="avatar-image"
                  aria-label='Avatar Image'
                />
              </div>
            </a>
            <ul className="dropdown-menu dropdown-menu-end">
              <li>
                <a aria-label='go to profile' className="dropdown-item" href="#">
                  <div className="d-flex">
                    <div className="flex-shrink-0 me-3">
                      <div className="avatar avatar-online">
                        <img
                          src={
                            user && user.photo !== ""
                              ? user.photo
                              : "/assets/img/avatars/1.png"
                          }
                          style={{ width: '40px', height: '40px' }}
                          className="w-px-40  rounded-circle"
                          alt='avatar-image' aria-label='Avatar Image'
                        />
                      </div>
                    </div>
                    <div className="flex-grow-1">
                      <span className="fw-medium d-block">{user ? user.first_name + ' ' + user.last_name : 'Guest'}</span>
                      <small className="text-muted">{user ? user.is_admin : 'Member'}</small>
                    </div>
                  </div>
                </a>
              </li>
              <li>
                <div className="dropdown-divider"></div>
              </li>
              <li>
                <a aria-label='go to profile' className="dropdown-item" href="/account/settings">
                  <i className="bx bx-user me-2"></i>
                  <span className="align-middle">My Profile</span>
                </a>
              </li>
              <li>
                <a aria-label='go to setting' className="dropdown-item" href="#" onClick={handleLogout}>
                  <i className="bx bx-lock me-2"></i>
                  <span className="align-middle">Log Out</span>
                </a>
              </li>
              {
                // <li>
                //   <a aria-label='go to setting' className="dropdown-item" href="#">
                //     <i className="bx bx-cog me-2"></i>
                //     <span className="align-middle">Settings</span>
                //   </a>
                // </li>
                // <li>
                //   <a aria-label='go to billing' className="dropdown-item" href="#">
                //     <span className="d-flex align-items-center align-middle">
                //       <i className="flex-shrink-0 bx bx-credit-card me-2"></i>
                //       <span className="flex-grow-1 align-middle ms-1">Billing</span>
                //       <span className="flex-shrink-0 badge badge-center rounded-pill bg-danger w-px-20 h-px-20">4</span>
                //     </span>
                //   </a>
                // </li>
              }

              <li>
                <div className="dropdown-divider"></div>
              </li>

            </ul>
          </li>
        </ul>
      </div>
    </nav>
  );
}
export default Navbar;